#!/bin/bash

rm -rf package.zip
zip -r package.zip *
